import{c as n,P as l,i as d}from"./index-BfHk-GPO.js";import{r,j as o,b as p}from"./ui-DVJ6EJIP.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=n("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]]);var c="Label",s=r.forwardRef((a,t)=>o.jsx(l.label,{...a,ref:t,onMouseDown:e=>{e.target.closest("button, input, select, textarea")||(a.onMouseDown?.(e),!e.defaultPrevented&&e.detail>1&&e.preventDefault())}}));s.displayName=c;var i=s;const m=p("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),f=r.forwardRef(({className:a,...t},e)=>o.jsx(i,{ref:e,className:d(m(),a),...t}));f.displayName=i.displayName;export{f as L,y as T};
